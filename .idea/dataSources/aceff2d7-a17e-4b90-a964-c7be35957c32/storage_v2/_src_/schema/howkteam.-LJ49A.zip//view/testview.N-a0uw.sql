create definer = root@localhost view testview as
select `howkteam`.`giaovien`.`MAGV`   AS `MAGV`,
       `howkteam`.`giaovien`.`HOTEN`  AS `HOTEN`,
       `howkteam`.`giaovien`.`LUONG`  AS `LUONG`,
       `howkteam`.`giaovien`.`PHAI`   AS `PHAI`,
       `howkteam`.`giaovien`.`NGSINH` AS `NGSINH`,
       `howkteam`.`giaovien`.`DIACHI` AS `DIACHI`,
       `howkteam`.`giaovien`.`GVQLCM` AS `GVQLCM`,
       `howkteam`.`giaovien`.`MABM`   AS `MABM`
from `howkteam`.`giaovien`;

